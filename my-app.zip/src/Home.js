import logo from './logo.svg';
import './Home.css';
import 'bootstrap/dist/css/bootstrap.min.css';

import { useState} from 'react';
import Nav from 'react-bootstrap/Nav'
import Navbar from 'react-bootstrap/Navbar'
import Container from 'react-bootstrap/Container'
import Button from 'react-bootstrap/Button'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Form from 'react-bootstrap/Form'
import Modal from 'react-bootstrap/Modal'



function Example() {
  const values = [true, 'sm-down', 'md-down', 'lg-down', 'xl-down', 'xxl-down'];
  const [fullscreen, setFullscreen] = useState(true);
  const [show, setShow] = useState(false);

  function handleShow(breakpoint) {
    setFullscreen(breakpoint);
    setShow(true);
  }

  return (
    <>
    
        <Button className="me-2" onClick={() => handleShow(true)}>
          Next
        
        </Button>
  
      <Modal show={show} fullscreen={fullscreen} onHide={() => setShow(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Proposal Edit</Modal.Title>
        </Modal.Header>
        <Modal.Body>
				<Form>
						
						  <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
							<Form.Label>content</Form.Label>
							<Form.Control as="textarea" rows={10} />
						  </Form.Group>
				</Form>
				
				<Button className="me-2" >
				  Send
				
				</Button>
			</Modal.Body>
      </Modal>
    </>
  );
}

function Home() {
  return (
<>

    
	<div className="head">
	
		<div  className="headleft">
		
			<img class="imgsize"   src="yue.png" />
			<div>Acc Proposal</div>
		</div>
		
		<div className="headright">
		
		
				<div>Erin</div>
				
				<div><input  placeholder="search" type="text" /></div>
				
				
		
		        <div className="headrighttou">
				
						<div> <img class="person" src="person.png" /></div>
						<div> 
							<select>
										<option value ="volvo">Volvo</option>

							</select>
						</div>
				
				</div>
		</div>
		
	</div>
	
	<div className="body">
	
			<div className="bodyleft">
			
			    <div className="yibiao">Dashboard</div>
			  
			    <div className="ul" >
				    <div>Client</div>
					<div><img className="topimg" src="top.png"/></div>
				</div>
				
				<div className="none li ">
				
				     <div className="li-t"> Create new Proposals </div>
				  
				      <div className="li-t"> Create new Proposals </div>
				</div>
				
				<div className="ul" >
				    <div>Proposals</div>
					<div><img className="topimg" src="top.png"/></div>
				</div>
				
				
				<div className="li ">
				
				     <div className="li-t xz"> Create new Proposals </div>
				  
				      <div className="li-t"> Export Proposals </div>
					  
					  
					  <div className="li-t"> Import Proposals </div>
					  
					  
					  <div className="li-t"> View Proposals </div>
				</div>
				
				
				<div className="ul" >
				    <div>Servie</div>
					<div><img className="topimg" src="top.png"/></div>
				</div>
				
				
				<div className="ul" >
				    <div>Library</div>
					<div><img className="topimg" src="top.png"/></div>
				</div>
			    
			
			</div>
			
			<div class="bodyright">
			
			     <>
			      <Form>
			        <Row className="mb-3">
			          <Form.Group as={Col} controlId="formGridEmail">
			            <Form.Label>Proposal Name</Form.Label>
			            <Form.Control type="text" placeholder="" />
			          </Form.Group>
			      
			          <Form.Group as={Col} controlId="formGridPassword">
			            <Form.Label>Client</Form.Label>
			           <Form.Select defaultValue="Choose...">
			             <option>Choose an option...</option>
			             <option>...</option>
			           </Form.Select>
			          </Form.Group>
			        </Row>
					
					
					<Row className="mb-3">
					  <Form.Group as={Col} controlId="formGridEmail">
					    <Form.Label>Contact</Form.Label>
					  <Form.Select defaultValue="Choose...">
					    <option>Choose an option...</option>
					    <option>...</option>
					  </Form.Select>
					  </Form.Group>
								      
					  <Form.Group as={Col} controlId="formGridPassword">
					    <Form.Label>Effective Start Date</Form.Label>
					   <Form.Select defaultValue="Choose...">
					     <option>Choose an option...</option>
					     <option>...</option>
					   </Form.Select>
					  </Form.Group>
					</Row>
			      
			        <Form.Group className="mb-3" controlId="formGridAddress1">
			          <Form.Label>Effiective Start Date</Form.Label>
			          <Form.Control placeholder="1234 Main St" />
			        </Form.Group>
			      
			        <Form.Group className="mb-3" controlId="formGridAddress2">
			          <Form.Label>Minimum Contract Length</Form.Label>
			          <Form.Select defaultValue="Choose...">
			            <option>12 Moth...</option>
			            <option>...</option>
			          </Form.Select>
			        </Form.Group>
			      
			        <Row className="mb-3">
			 
			      
			          <Form.Group as={Col} controlId="formGridState">
			            <Form.Label>Recurring Billing</Form.Label>
			            <Form.Select defaultValue="Choose...">
			              <option>Weekly...</option>
			              <option>...</option>
			            </Form.Select>
			          </Form.Group>
			      
			          <Form.Group as={Col} controlId="formGridState">
			            <Form.Label>One time Billing</Form.Label>
			            <Form.Select defaultValue="Choose...">
			              <option>On Acceptance...</option>
			              <option>...</option>
			            </Form.Select>
			          </Form.Group>
			        </Row>
		
			      
			     
					<Example />
					
			      </Form>
			     
			     </>
			</div>
			
	
	</div>
      
		  
		
  
</>
  );
}

export default Home;
